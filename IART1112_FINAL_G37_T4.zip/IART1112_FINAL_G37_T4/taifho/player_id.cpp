/*
 * player_id.cpp
 *
 *  Created on: 14 de Abr de 2012
 *      Author: ei10001
 */

#include "player_id.h"

const Player_ID NO_PLAYER(0);
const Player_ID PLAYER_RED(1);
const Player_ID PLAYER_BLUE(2);
const Player_ID PLAYER_GREEN(3);
const Player_ID PLAYER_YELLOW(4);

