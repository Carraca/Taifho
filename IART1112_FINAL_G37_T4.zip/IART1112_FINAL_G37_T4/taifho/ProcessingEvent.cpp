#include "ProcessingEvent.h"

ProcessingEvent::ProcessingEvent()
{

}

bool ProcessingEvent::isProcessing()
{
	return true;
}
