#ifndef _VERTEX_STRUCT
#define _VERTEX_STRUCT

#define INX_TYPE GL_UNSIGNED_SHORT

struct vertex_struct{
	float x, y, z;
	float nx,ny,nz;
	float u,v;
};

#endif