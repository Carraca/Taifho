#ifndef PLAYER_ID_H_
#define PLAYER_ID_H_

typedef unsigned int Player_ID;
extern const Player_ID NO_PLAYER;
extern const Player_ID PLAYER_RED;
extern const Player_ID PLAYER_GREEN;
extern const Player_ID PLAYER_YELLOW;
extern const Player_ID PLAYER_BLUE;

#endif /* PLAYER_ID_H_ */
